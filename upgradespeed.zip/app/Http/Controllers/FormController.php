<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use DB;

class FormController extends Controller
{
    public function index()
    {
        $getSpeed = DB::select('SELECT DISTINCT SPEED FROM UPSPEED_MASTER');
        $data = [
            'title' => 'Upgrade Speed',
            'speed' => $getSpeed
        ];

        return view('form');
    }

    public function register(Request $request)
    {
        $rules = [
            'nomor_hp'        => 'required',
            'nomor_inet'      => 'required',
            'nama_pelanggan'  => 'required',
            'email_pelanggan' => 'required',
            'up_to_speed'     => 'required',
            'cur_speed'       => 'required',
            'price'           => 'required'
        ];

        $isValid = Validator::make($request->all(),$rules);

        if($isValid->fails()){
            return redirect()->back()->withInput()->withErrors($isValid->errors());
        }else{
            $data = [
                'nomor_hp'        => $request->input('nomor_hp'),
                'nomor_inet'      => $request->input('nomor_inet'),
                'nama_pelanggan'  => $request->input('nama_pelanggan'),
                'email_pelanggan' => $request->input('email_pelanggan'),
                'up_to_speed'     => $request->input('up_to_speed'),
                'cur_speed'       => $request->input('cur_speed'),
                'price'           => $request->input('price')
            ];

            $insert = DB::table('upspeed_new')->insert($data);

            if($insert){
                return redirect()->back()->with('success','Pendaftaran berhasil!');
            }else{
                return redirect()->back()->with('error','Terjadi kesalahan! pendaftaran gagal!');
            }
        }
    }

    public function getNumber(Request $request)
    {
        $nomor_hp = $request->input('nomor_hp');

        $query = DB::select("SELECT * FROM UPSPEED_MASTER WHERE ND_INTERNET LIKE '%$nomor_hp%'");

        if($query){
           return response([
               'status' => 200,
               'data' => $query[0]
           ]);
        }else{
            return response([
                'status' => 500,
                'data' => [],
                'message' => 'Data tidak ditemukan!'
            ]);
        }
    }
}
